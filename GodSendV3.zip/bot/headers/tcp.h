#pragma once

#include "includes.h"
unsigned char killer_kill_by_port(uint16_t port);
